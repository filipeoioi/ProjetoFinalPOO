package CodFelipe;

public interface IUsuario {
    public abstract Login getLogin();
    public abstract void setLogin(Login login);   
    public abstract String getTipo();
}
